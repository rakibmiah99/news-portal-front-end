const site = {
    base_url: "http://nikash-online.com/news_portal/public/api",
    url: function (getUrl){
        return this.base_url+getUrl;
    }
}



function convertDate(givenDate){
    let date = new Date(givenDate);
    let year = date.getFullYear();
    let month = String(date.getMonth() + 1).padStart(2, '0');
    let day = String(date.getDate()).padStart(2, '0');
    return  joinedDate = [year, month, day].join('-');
}
