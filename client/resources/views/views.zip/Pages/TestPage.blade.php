<html>
    <head>
        <style>
            .flex-container{
                display: flex;
            }

            .one{
                background: red;
                height: 200px;
            }
            .two{
                background: green;
                height: 200px;
            }
            .th{
                background: blue;
                height: 200px;
            }
        </style>
    </head>
    <body>
        <div class="flex-container">
            <div class="one" style="flex-basis: 300px;"> 1 </div>
            <div class="two"> 2 </div>
            <div class="th"> 3 </div>
        </div>
    </body>
</html>
