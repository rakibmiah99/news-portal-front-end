<div class="mt-5">
    <div class="section-container">
        <div class="border-top shadow-sm border-bottom border-secondary  p-2  d-flex justify-content-between align-items-center">
            <h4 class="m-0">রাজনীতি</h4>
            <button class="btn btn-danger rounded-pill">সকল</button>
        </div>
    </div>
</div>

<div id="politics" class="section-container">
    <div class="row mt-3">
        <div class="pLeadNes col-12 col-sm-12 col-md-7 col-lg-6">
            <div class="row">
                <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                    <a href="#" class="card mt-3 link overflow-hidden w-100" style="height: 360px;">
                        <img height="200px" style="object-fit: cover" src="{{asset("img/rajniti1.jpg")}}" class="card-img-top img-fluid" alt="Tittle">
                        <div class="card-body">
                            <h5 class="card-text fw-bold">বাসার ভাই ৫৫৮ ‘এর চেয়ে ৫ লিটার সয়াবিন তেল কিনলে কাজ হতো’</h5>
                            <p class="d-lg-block d-md-none">জনপ্রিয় কণ্ঠশিল্পী সৈয়দ আব্দুল হাদীর আত্মজীবনী জীবনের গান বইয়ের মোড়ক উন্মোচন করা হলো মঙ্গলবার। বইটি প্রকাশিত হয়েছে প্রথমা প্রকাশন</p>
                            <div class="d-flex justify-content-between">
                                <div class="d-flex f-13 align-items-center"><i class="fas fa-clock" style="margin-right: 5px"></i> ১৩ ঘন্টা আগে</div>
                                <div class="f-13"><i class="fas fa-tags" style="margin-right: 5px"></i> অর্থনীতি </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                    <a href="#" class="card mt-3  link w-100" style="height: 360px;">
                        <img height="200px" style="object-fit: cover" src="{{asset("img/rajniti2.png")}}" class="card-img-top" alt="Tittle">
                        <div class="card-body">
                            <h5 class="card-text fw-bold">বাসার ভাই ৫৫৮ ‘এর চেয়ে ৫ লিটার সয়াবিন তেল কিনলে কাজ হতো’</h5>
                            <p class="rajnitiDesc  d-lg-block d-md-none">জনপ্রিয় কণ্ঠশিল্পী সৈয়দ আব্দুল হাদীর আত্মজীবনী জীবনের গান বইয়ের মোড়ক উন্মোচন করা হলো মঙ্গলবার। বইটি প্রকাশিত হয়েছে প্রথমা প্রকাশন</p>
                            <div class="d-flex justify-content-between">
                                <div class="d-flex f-13 align-items-center"><i class="fas fa-clock" style="margin-right: 5px"></i> ১৩ ঘন্টা আগে</div>
                                <div class="f-13"><i class="fas fa-tags" style="margin-right: 5px"></i> অর্থনীতি </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                    <a href="#" class="card mt-3 w-100 link" style="height: 360px;">
                        <img height="200px" style="object-fit: cover" src="{{asset("img/rajniti2.png")}}" class="card-img-top img-fluid" alt="Tittle">
                        <div class="card-body">
                            <h5 class="card-text fw-bold ">বাসার ভাই ৫৫৮ ‘এর চেয়ে ৫ লিটার সয়াবিন তেল কিনলে কাজ হতো’</h5>
                            <p class="rajnitiDesc  d-md-none d-lg-block">জনপ্রিয় কণ্ঠশিল্পী সৈয়দ আব্দুল হাদীর আত্মজীবনী জীবনের গান বইয়ের মোড়ক উন্মোচন করা হলো মঙ্গলবার।</p>
                            <div class="d-flex justify-content-between">
                                <div class="d-flex f-13 align-items-center"><i class="fas fa-clock" style="margin-right: 5px"></i> ১৩ ঘন্টা আগে</div>
                                <div class="f-13"><i class="fas fa-tags" style="margin-right: 5px"></i> অর্থনীতি </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                    <a href="#" class="card mt-3 w-100 link" style="height: 360px;">
                        <img height="200px" style="object-fit: cover" src="{{asset("img/rajniti1.jpg")}}" height="180px" class="card-img-top img-fluid" alt="Tittle">
                        <div class="card-body">
                            <h5 class="card-text fw-bold">বাসার ভাই ৫৫৮ ‘এর চেয়ে ৫ লিটার সয়াবিন তেল কিনলে কাজ হতো’</h5>
                            <p class="rajnitiDesc  d-md-none d-lg-block">জনপ্রিয় কণ্ঠশিল্পী সৈয়দ আব্দুল হাদীর আত্মজীবনী জীবনের গান বইয়ের মোড়ক উন্মোচন করা হলো মঙ্গলবার। বইটি প্রকাশিত হয়েছে প্রথমা প্রকাশন</p>
                            <div class="d-flex justify-content-between">
                                <div class="d-flex f-13 align-items-center"><i class="fas fa-clock" style="margin-right: 5px"></i> ১৩ ঘন্টা আগে</div>
                                <div class="f-13"><i class="fas fa-tags" style="margin-right: 5px"></i> অর্থনীতি </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <div class="psLeadNews col-12 col-sm-12 col-md-5 col-lg-3">
            <div class="titleNews2 mt-3">
                <a href="#" class="news link border-bottom mt-2 mb-2">
                    <img class="image" src="{{asset('img/titleNews.jpg')}}">
                    <div>
                        <h5 class="title">রাশিয়া-ইউক্রেন যুদ্ধের সর্বশেষ</h5>
                        <p class="hour"><i class="fas  fa-clock" style="margin: 0 5px 0 0;"></i>২ ঘন্টা আগে</p>
                    </div>
                </a>
                <a href="#" class="news link border-bottom mt-2 mb-2">
                    <img class="image" src="{{asset('img/titleNews.jpg')}}">
                    <div>
                        <h5 class="title">রাশিয়া-ইউক্রেন যুদ্ধের সর্বশেষ</h5>
                        <p class="hour"><i class="fas  fa-clock" style="margin: 0 5px 0 0;"></i>২ ঘন্টা আগে</p>
                    </div>
                </a>
                <a href="#" class="news link border-bottom mt-2 mb-2">
                    <img class="image" src="{{asset('img/titleNews.jpg')}}">
                    <div>
                        <h5 class="title">রাশিয়া-ইউক্রেন যুদ্ধের সর্বশেষ</h5>
                        <p class="hour"><i class="fas  fa-clock" style="margin: 0 5px 0 0;"></i>২ ঘন্টা আগে</p>
                    </div>
                </a>
                <a href="#" class="news link border-bottom mt-2 mb-2">
                    <img class="image" src="{{asset('img/titleNews.jpg')}}">
                    <div>
                        <h5 class="title">রাশিয়া-ইউক্রেন যুদ্ধের সর্বশেষ</h5>
                        <p class="hour"><i class="fas  fa-clock" style="margin: 0 5px 0 0;"></i>২ ঘন্টা আগে</p>
                    </div>
                </a>
                <a href="#" class="news link border-bottom mt-2 mb-2">
                    <img class="image" src="{{asset('img/titleNews.jpg')}}">
                    <div>
                        <h5 class="title">রাশিয়া-ইউক্রেন যুদ্ধের সর্বশেষ</h5>
                        <p class="hour"><i class="fas  fa-clock" style="margin: 0 5px 0 0;"></i>২ ঘন্টা আগে</p>
                    </div>
                </a>
                <a href="#" class="news link border-bottom mt-2 mb-2">
                    <img class="image" src="{{asset('img/titleNews.jpg')}}">
                    <div>
                        <h5 class="title">রাশিয়া-ইউক্রেন যুদ্ধের সর্বশেষ</h5>
                        <p class="hour"><i class="fas  fa-clock" style="margin: 0 5px 0 0;"></i>২ ঘন্টা আগে</p>
                    </div>
                </a>
            </div>
        </div>
        <div class="mapArchive mt-3 col-12 col-sm-12 col-md-12 col-lg-3">
            <div class="row justify-content-md-between  justify-content-center">
                <div class="col-12 col-md-6 mt-5" id="map"></div>
                <div class="areaChose col-12 col-md-6 col-lg-12  mt-5">
                    <h3 class="text-center mt-3 border-bottom border-top bg-light p-2">আমাদের খবর</h3>
                    <div class="form mt-3">
                        <select class="form-select shadow-none mt-3" aria-label="Default select example">
                            <option selected>বিভাগ</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                        <select class="form-select shadow-none mt-3" aria-label="Default select example">
                            <option selected>জেলা </option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                        <select class="form-select shadow-none mt-3" aria-label="Default select example">
                            <option selected>উপজেলা </option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                        <button class="btn btn-danger shadow-none text-center mt-3 w-100">খুজুন</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


{{--ADVERTISE SECTION--}}
<div class="addBanner mt-5 mb-5 d-flex justify-content-center">
    <img src="{{asset("img/bigBanner.png")}}">
</div>
