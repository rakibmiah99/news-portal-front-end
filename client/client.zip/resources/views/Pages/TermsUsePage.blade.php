@extends('Layout.app')
@section('title', "ব্যবহারের শর্তাবলি")


@section('content')
    <div id="cms"  class="section-container mt-2">

    </div>

    <script>
        CMS('/cms/terms_and_condition');
    </script>
@endsection
