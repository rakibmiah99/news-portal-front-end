@extends('Layout.app')
@section('title', "বিজ্ঞাপন")


@section('content')
    <div id="cms"  class="section-container mt-2">

    </div>

    <script>
        CMS('/cms/advertise');
    </script>
@endsection
