<div id="tranding" class="section-container ">
    <div class="keywords mt-2 mb-2">
        <label style="margin-right: 10px;" class="f-18">ট্রেন্ডিংঃ </label>
        <a href="#" class="btn btn-sm btn-danger m-2">সার্চ কমিটি </a>
        <a href="#" class="btn btn-sm btn-danger m-2">সার্চ কমিটি </a>
        <a href="#" class="btn btn-sm btn-danger m-2">সার্চ কমিটি </a>
        <a href="#" class="btn btn-sm btn-danger m-2">সার্চ কমিটি </a>
        <a href="#" class="btn btn-sm btn-danger m-2">সার্চ কমিটি </a>
        <a href="#" class="btn btn-sm btn-danger m-2">সার্চ কমিটি </a>
        <a href="#" class="btn btn-sm btn-danger m-2">সার্চ কমিটি </a>
        <a href="#" class="btn btn-sm btn-danger m-2">সার্চ কমিটি </a>
    </div>
</div>
