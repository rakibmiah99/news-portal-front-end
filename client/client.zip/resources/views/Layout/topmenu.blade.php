<div id="top-nav" class="bg-light border-top border-bottom shadow-sm">
    <nav class="navbar section-container navbar-light navbar-expand-md  d-none d-md-block">
        <div class="container-fluid">
            <div class="collapse navbar-collapse d-flex justify-content-center" id="navbarSupportedContent">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">প্রচ্ছদ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">সর্বশেষ সংবাদ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">সর্বশেষ সংবাদ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">বিশেষ সংবাদ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">করোনাভাইরাস</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">বাংলাদেশ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">বিশ্ব</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            বাণিজ্য
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">মতামত</a></li>
                            <li><a class="dropdown-item" href="#">খেলা</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</div>
