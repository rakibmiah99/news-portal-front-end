<div class="offcanvas offcanvas-start" tabindex="-1" id="sideMenu" aria-labelledby="sideMenuLabel">
    <div class="offcanvas-header d-flex justify-content-end">
        <button type="button" class="btn-close btn text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <ul class="list-group list-group-item-action list-group-flush">
            <a href="#" class="list-group-item list-group-item-action">প্রচ্ছদ</a>
            <a href="#" class="list-group-item list-group-item-action">সর্বশেষ সংবাদ</a>
            <a href="#" class="list-group-item list-group-item-action">বিশেষ সংবাদ</a>
            <a href="#" class="list-group-item list-group-item-action">করোনাভাইরাস</a>
            <a href="#" class="list-group-item list-group-item-action">বাংলাদেশ</a>
            <a href="#" class="list-group-item list-group-item-action">বিশ্ব</a>
            <a href="#" class="list-group-item list-group-item-action">বাণিজ্য</a>
            <a href="#" class="list-group-item list-group-item-action">মতামত</a>
            <a href="#" class="list-group-item list-group-item-action">খেলা</a>
            <a href="#" class="list-group-item list-group-item-action">প্রচ্ছদ</a>
            <a href="#" class="list-group-item list-group-item-action">সর্বশেষ সংবাদ</a>
            <a href="#" class="list-group-item list-group-item-action">বিশেষ সংবাদ</a>
            <a href="#" class="list-group-item list-group-item-action">করোনাভাইরাস</a>
            <a href="#" class="list-group-item list-group-item-action">বাংলাদেশ</a>
            <a href="#" class="list-group-item list-group-item-action">বিশ্ব</a>
            <a href="#" class="list-group-item list-group-item-action">বাণিজ্য</a>
            <a href="#" class="list-group-item list-group-item-action">মতামত</a>
            <a href="#" class="list-group-item list-group-item-action">খেলা</a>
            <a href="#" class="list-group-item list-group-item-action">প্রচ্ছদ</a>
            <a href="#" class="list-group-item list-group-item-action">সর্বশেষ সংবাদ</a>
            <a href="#" class="list-group-item list-group-item-action">বিশেষ সংবাদ</a>
            <a href="#" class="list-group-item list-group-item-action">করোনাভাইরাস</a>
            <a href="#" class="list-group-item list-group-item-action">বাংলাদেশ</a>
            <a href="#" class="list-group-item list-group-item-action">বিশ্ব</a>
            <a href="#" class="list-group-item list-group-item-action">বাণিজ্য</a>
            <a href="#" class="list-group-item list-group-item-action">মতামত</a>
            <a href="#" class="list-group-item list-group-item-action">খেলা</a>
        </ul>
    </div>
</div>
