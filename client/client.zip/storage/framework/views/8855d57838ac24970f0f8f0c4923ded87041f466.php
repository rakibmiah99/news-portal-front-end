<!DOCTYPE html>
<html>
    <head>
        <style>
            table{
                background: #a3a3a3;
                width: 100%;
                border-radius: 10px;
                border: none;
            }
            table tr{
                border: none;
            }
            table tr td{
                border: none;
            }
            table tr:nth-child(even) td{
                background: white
            }

        </style>
    </head>
    <body >


        <a href="https://google.com">google</a>
        <a href="https://www.youtube.com/">Sakib</a>
    </body>
</html>
<?php /**PATH C:\Users\rakib\Documents\GitHub\news-portal\client\resources\views/Welcome.blade.php ENDPATH**/ ?>